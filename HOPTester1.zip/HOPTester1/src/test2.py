# Test 1 Use Case 2 - Correct (Positive) value test
# Author Radovan Mitrovic
# Date 2019-May-25

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import NoAlertPresentException
import unittest, time, re
from pom import TestFlow


class TestProper(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Chrome()
        self.driver.implicitly_wait(5)
        self.base_url = "https://www.ultimateqa.com/filling-out-forms/"
        self.driver.maximize_window()
        self.verificationErrors = []
        self.accept_next_alert = True
# Fill in data
    def test_proper_value(self, calval=None):
        driver = self.driver
        driver.get(self.base_url + "/")

        addpropervalue = TestFlow(driver)

        addpropervalue.testName('Testnamee')
        addpropervalue.testMessage('Testmessagee')
        addpropervalue.setCaptcha(calval)
        addpropervalue.submit()
        print(driver.find_element_by_class_name('et-pb-contact-message').get_attribute("Success"))
        driver.close()

# Element is missing - throw excpt
    def is_element_present(self, how, what):
        try:
            self.driver.find_element(by=how, value=what)
        except NoSuchElementException as e:
            return False
        return True

# Alert is missing - throw excpt
    def is_alert_present(self):
        try:
            self.driver.switch_to.alert()
        except NoAlertPresentException as e:
            return False
        return True
# Close
    def tearDown(self):
        self.driver.quit()
        self.assertEqual([], self.verificationErrors)


if __name__ == "__main__":
    unittest.main()


class login():

    def TestProper(self, user_name):
        print("Enter test_name to Testname field on Form.")



